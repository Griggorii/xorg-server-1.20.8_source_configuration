#Only real technologies, not any fictional parasitic distributions support real technology investments and donate VISA 4817 7601 8112 470 

Special OS 20.04 https://youtu.be/MVhZ_QZGxaQ

4 Variants xorg test perfomance game benchmark and gamma cilir graphic

sudo tar xvpf xorg_1.20.8_inoi_libglx.tar.xz -C /

and

sudo tar xvpf xorg_1.20.4.tar.xz -C /

and

sudo tar xvpf xorg_1.20.8_make.tar.xz -C /

and

sudo tar xvpf xorg_1.20.8_meson.tar.xz -C /

_________________________________________________________________________________________________

Folder xorg_ubuntu-20.04-special-os 

CTRL+H 

less wayland perfomance .bashrc

CTRL+H 

backup original ~/.bashrc replace bashrc run terminal
