#Only real technologies, not any fictional parasitic distributions support real technology investments and donate VISA 4817 7601 8112 4706

####Griggorii@gmail.com mit license Test_wayland-bash_perfomance?.zip CTRL+H on hidden files /home/<user>

GREEN='\[\e[033[1;32m\]'
RED='\[\e[033[0;31m\]'
YELLOW='\[\e[033[1;33m\]'
ENDCOLOR='\[\e[033[0m\]'
COLOR_BLACK='\[\e[0;30m\]'
COLOR_BLUE='\[\e[0;34m\]'
COLOR_GREEN='\[\e[0;32m\]'
COLOR_CYAN='\[\e[0;36m\]'
COLOR_PINK='\[\e[0;35m\]'
COLOR_RED='\[\e[0;31m\]'
COLOR_PURPLE='\[\e[0;35m\]'
COLOR_BROWN='\[\e[0;33m\]'
COLOR_LIGHTGRAY='\[\e[0;37m\]'
COLOR_DARKGRAY='\[\e[1;30m\]'
COLOR_LIGHTBLUE='\[\e[1;34m\]'
COLOR_LIGHTGREEN='\[\e[1;32m\]'
COLOR_LIGHTCYAN='\[\e[1;36m\]'
COLOR_LIGHTRED='\[\e[1;31m\]'
COLOR_LIGHTPURPLE='\[\e[1;35m\]'
COLOR_YELLOW='\[\e[1;33m\]'
COLOR_WHITE='\[\e[1;37m\]'
COLOR_NONE='\[\e[0m\]'
red='\[\e[0;31m\]'
RED='\[\e[1;31m\]'
blue='\[\e[0;34m\]'
BLUE='\[\e[1;34m\]'
cyan='\[\e[0;36m\]'
CYAN='\[\e[1;36m\]'
green='\[\e[0;32m\]'
GREEN='\[\e[1;32m\]'
yellow='\[\e[0;33m\]'
YELLOW='\[\e[1;33m\]'
PURPLE='\[\e[1;35m\]'
purple='\[\e[0;35m\]'
nc='\[\e[0m\]'

if [ "$UID" = 0 ]; then
    PS1="$red\u$nc@$red\H$nc:$CYAN\w$nc\\n$red#$nc "
else
    PS1="$PURPLE\u$CYAN📎$COLOR_LIGHTBLUE\H$COLOR_DARKGRAY:$COLOR_GREEN\w$COLOR_GREEN\n$red\$$COLOR_LIGHTCYAN "
fi && clear 
